create function interval_pl_time(interval, time without time zone) returns time without time zone
    immutable
    strict
    parallel safe
    cost 1
    language sql
as
$$
    begin
-- missing source code
end;
$$;

comment on function interval_pl_time(interval, time) is 'implementation of + operator';

alter function interval_pl_time(interval, time) owner to "dam.kasimov";

