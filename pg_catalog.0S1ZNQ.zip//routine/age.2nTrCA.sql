create function age(timestamp with time zone) returns interval
    stable
    strict
    parallel safe
    cost 1
    language sql
as
$$
    begin
-- missing source code
end;
$$;

comment on function age(timestamp with time zone, timestamp with time zone) is 'date difference preserving months and years';

alter function age(timestamp with time zone, timestamp with time zone) owner to "dam.kasimov";

