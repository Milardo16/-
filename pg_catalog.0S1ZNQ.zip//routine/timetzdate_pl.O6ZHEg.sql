create function timetzdate_pl(time with time zone, date) returns timestamp with time zone
    immutable
    strict
    parallel safe
    cost 1
    language sql
as
$$
    begin
-- missing source code
end;
$$;

comment on function timetzdate_pl(time with time zone, date) is 'implementation of + operator';

alter function timetzdate_pl(time with time zone, date) owner to "dam.kasimov";

