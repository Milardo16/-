create function pg_relation_size(regclass) returns bigint
    strict
    parallel safe
    cost 1
    language sql
as
$$
    begin
-- missing source code
end;
$$;

comment on function pg_relation_size(regclass, text) is 'disk space usage for the specified fork of a table or index';

alter function pg_relation_size(regclass, text) owner to "dam.kasimov";

