create function "overlaps"(time without time zone, time without time zone, time without time zone, interval) returns boolean
    immutable
    parallel safe
    cost 1
    language sql
as
$$
    begin
-- missing source code
end;
$$;

comment on function "overlaps"(time, time, time, interval) is 'intervals overlap?';

alter function "overlaps"(time, time, time, interval) owner to "dam.kasimov";

