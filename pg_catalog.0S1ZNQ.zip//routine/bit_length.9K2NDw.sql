create function bit_length(bit) returns integer
    immutable
    strict
    parallel safe
    cost 1
    language sql
as
$$
    begin
-- missing source code
end;
$$;

comment on function bit_length(bit) is 'length in bits';

alter function bit_length(bit) owner to "dam.kasimov";

