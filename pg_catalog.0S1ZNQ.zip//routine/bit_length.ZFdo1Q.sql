create function bit_length(text) returns integer
    immutable
    strict
    parallel safe
    cost 1
    language sql
as
$$
    begin
-- missing source code
end;
$$;

comment on function bit_length(text) is 'length in bits';

alter function bit_length(text) owner to "dam.kasimov";

