create function trunc(numeric) returns numeric
    immutable
    strict
    parallel safe
    cost 1
    language sql
as
$$
    begin
-- missing source code
end;
$$;

comment on function trunc(numeric) is 'MACADDR8 manufacturer fields';

alter function trunc(numeric) owner to "dam.kasimov";

