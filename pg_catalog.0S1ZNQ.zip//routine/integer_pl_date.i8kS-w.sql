create function integer_pl_date(integer, date) returns date
    immutable
    strict
    parallel safe
    cost 1
    language sql
as
$$
    begin
-- missing source code
end;
$$;

comment on function integer_pl_date(integer, date) is 'implementation of + operator';

alter function integer_pl_date(integer, date) owner to "dam.kasimov";

