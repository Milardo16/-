create function bit_length(bytea) returns integer
    immutable
    strict
    parallel safe
    cost 1
    language sql
as
$$
    begin
-- missing source code
end;
$$;

comment on function bit_length(bytea) is 'length in bits';

alter function bit_length(bytea) owner to "dam.kasimov";

