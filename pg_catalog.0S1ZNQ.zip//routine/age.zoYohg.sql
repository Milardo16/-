create function age(timestamp without time zone) returns interval
    stable
    strict
    parallel safe
    cost 1
    language sql
as
$$
    begin
-- missing source code
end;
$$;

comment on function age(timestamp, timestamp) is 'date difference preserving months and years';

alter function age(timestamp, timestamp) owner to "dam.kasimov";

