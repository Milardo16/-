create function obj_description(oid, name) returns text
    stable
    strict
    parallel safe
    language sql
as
$$
    begin
-- missing source code
end;
$$;

comment on function obj_description(oid, name) is 'deprecated, use two-argument form instead';

alter function obj_description(oid, name) owner to "dam.kasimov";

