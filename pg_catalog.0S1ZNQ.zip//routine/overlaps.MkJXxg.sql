create function "overlaps"(timestamp without time zone, timestamp without time zone, timestamp without time zone, interval) returns boolean
    immutable
    parallel safe
    cost 1
    language sql
as
$$
    begin
-- missing source code
end;
$$;

comment on function "overlaps"(timestamp, timestamp, timestamp, interval) is 'intervals overlap?';

alter function "overlaps"(timestamp, timestamp, timestamp, interval) owner to "dam.kasimov";

