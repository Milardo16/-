create function "overlaps"(timestamp with time zone, interval, timestamp with time zone, interval) returns boolean
    stable
    parallel safe
    cost 1
    language sql
as
$$
    begin
-- missing source code
end;
$$;

comment on function "overlaps"(timestamp with time zone, interval, timestamp with time zone, interval) is 'intervals overlap?';

alter function "overlaps"(timestamp with time zone, interval, timestamp with time zone, interval) owner to "dam.kasimov";

