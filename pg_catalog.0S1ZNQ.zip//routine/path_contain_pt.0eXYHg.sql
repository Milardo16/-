create function path_contain_pt(path, point) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language sql
as
$$
    begin
-- missing source code
end;
$$;

comment on function path_contain_pt(path, point) is 'implementation of @> operator';

alter function path_contain_pt(path, point) owner to "dam.kasimov";

