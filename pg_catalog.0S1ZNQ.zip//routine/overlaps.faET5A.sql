create function "overlaps"(timestamp with time zone, interval, timestamp with time zone, timestamp with time zone) returns boolean
    stable
    parallel safe
    cost 1
    language sql
as
$$
    begin
-- missing source code
end;
$$;

comment on function "overlaps"(timestamp with time zone, interval, timestamp with time zone, timestamp with time zone) is 'intervals overlap?';

alter function "overlaps"(timestamp with time zone, interval, timestamp with time zone, timestamp with time zone) owner to "dam.kasimov";

