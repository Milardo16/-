create function log(numeric) returns numeric
    immutable
    strict
    parallel safe
    cost 1
    language sql
as
$$
    begin
-- missing source code
end;
$$;

comment on function log(numeric) is 'base 10 logarithm';

alter function log(numeric) owner to "dam.kasimov";

