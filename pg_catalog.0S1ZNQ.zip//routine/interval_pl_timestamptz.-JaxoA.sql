create function interval_pl_timestamptz(interval, timestamp with time zone) returns timestamp with time zone
    stable
    strict
    parallel safe
    cost 1
    language sql
as
$$
    begin
-- missing source code
end;
$$;

comment on function interval_pl_timestamptz(interval, timestamp with time zone) is 'implementation of + operator';

alter function interval_pl_timestamptz(interval, timestamp with time zone) owner to "dam.kasimov";

