create function ts_debug(document text, OUT alias text, OUT description text, OUT token text, OUT dictionaries regdictionary[], OUT dictionary regdictionary, OUT lexemes text[]) returns SETOF record
    stable
    strict
    parallel safe
    language sql
as
$$
    begin
-- missing source code
end;
$$;

comment on function ts_debug(text, out text, out text, out text, out regdictionary[], out regdictionary, out text[], out text[]) is 'debug function for text search configuration';

alter function ts_debug(text, out text, out text, out text, out regdictionary[], out regdictionary, out text[], out text[]) owner to "dam.kasimov";

